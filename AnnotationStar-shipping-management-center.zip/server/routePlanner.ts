import { invokeLLM, listLLMModels } from "./_core/llm";
import { makeRequest, type DirectionsResult } from "./_core/map";

export const VEHICLE_PROFILE = "青ナンバー軽トラック（ハイルーフ仕様、全高約2.0m前後）。横浜市内等の一般的な道路は通行可能だが、高架下・高さ制限・狭路・時間帯規制に注意。";

export type RouteDestination = {
  id: number;
  address: string;
  cargoInfo?: string;
};

export type RouteLocation = {
  lat: number;
  lng: number;
};

export type DeliveryEta = {
  taskId: number;
  eta: string;
  durationSeconds: number;
  baselineDurationSeconds: number;
  delaySeconds: number;
  distanceMeters: number;
  status: "on-time" | "late" | "unknown";
};

export async function estimateDeliveryEtas(input: { currentLocation: RouteLocation; destinations: RouteDestination[]; nowMs?: number }): Promise<DeliveryEta[]> {
  if (!input.destinations.length) return [];
  const origin = `${input.currentLocation.lat},${input.currentLocation.lng}`;
  const ordered = input.destinations;
  const result = await makeRequest<DirectionsResult>("/maps/api/directions/json", {
    origin,
    destination: ordered[ordered.length - 1].address,
    waypoints: ordered.slice(0, -1).map(destination => destination.address).join("|"),
    mode: "driving",
    departure_time: "now",
    traffic_model: "best_guess",
    alternatives: false,
  });
  if (result.status !== "OK" || !result.routes[0]) {
    return ordered.map(destination => ({ taskId: destination.id, eta: "--:--", durationSeconds: 0, baselineDurationSeconds: 0, delaySeconds: 0, distanceMeters: 0, status: "unknown" as const }));
  }
  const legs = result.routes[0].legs as Array<DirectionsResult["routes"][number]["legs"][number] & { duration_in_traffic?: { text: string; value: number } }>;
  let elapsedSeconds = 0;
  const nowMs = input.nowMs ?? Date.now();
  return ordered.map((destination, index) => {
    const leg = legs[index];
    const durationSeconds = leg?.duration_in_traffic?.value ?? leg?.duration?.value ?? 0;
    const baselineDurationSeconds = leg?.duration?.value ?? durationSeconds;
    const delaySeconds = Math.max(0, durationSeconds - baselineDurationSeconds);
    elapsedSeconds += durationSeconds;
    return {
      taskId: destination.id,
      eta: new Date(nowMs + elapsedSeconds * 1000).toISOString(),
      durationSeconds,
      baselineDurationSeconds,
      delaySeconds,
      distanceMeters: leg?.distance?.value ?? 0,
      status: delaySeconds >= 180 ? "late" : "on-time",
    };
  });
}

async function resolveGeminiModel() {
  const preferred = ["gemini-1.5-flash", "gemini-1.5-pro"];
  try {
    const catalog = await listLLMModels();
    const exact = preferred.find(model => catalog.data.some(item => item.id === model));
    if (exact) return exact;
    const currentGemini = catalog.data.find(item => item.id.toLowerCase().startsWith("gemini-"));
    if (currentGemini) return currentGemini.id;
  } catch {
    // Use the requested default if the model catalog is temporarily unavailable.
  }
  return preferred[0];
}

export async function optimizeDeliveryRoute(input: { currentLocation: RouteLocation | null; destinations: RouteDestination[] }) {
  if (input.destinations.length < 1) {
    throw new Error("配送先を1件以上選択してください");
  }
  if (input.destinations.length > 20) {
    throw new Error("一度に最適化できる配送先は20件までです");
  }

  const currentLocation = input.currentLocation
    ? `${input.currentLocation.lat}, ${input.currentLocation.lng}`
    : "現在地は取得できていません";

  const model = await resolveGeminiModel();
  const response = await invokeLLM({
    model,
    thinking: { budget_tokens: 512 },
    max_tokens: 1200,
    messages: [
      {
        role: "system",
        content: "あなたは日本の配送物流に詳しいルートディレクターです。与えられた配送先のIDを変更せず、必ず入力されたIDだけを使って、実運行で確認しやすい配送順序と注意点を日本語で返してください。住所の不確実性や高さ制限は断定せず、現地標識と公式規制を優先するよう明記してください。",
      },
      {
        role: "user",
        content: `以下の条件で配送ルートを最適化してください。\n\n【現在地】\n${currentLocation}\n\n【車両条件】\n${VEHICLE_PROFILE}\n\n【配送先一覧】\n${JSON.stringify(input.destinations, null, 2)}\n\n距離だけでなく、現在地からの流れ、横浜エリア等の時間帯規制、高架下・高さ制限・狭い生活道路、荷下ろししやすさ、未完了配送の優先度を考慮してください。Google Mapsの実走ルートと交通状況で最終確認する前提です。`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "delivery_route_plan",
        strict: true,
        schema: {
          type: "object",
          properties: {
            orderedStopIds: { type: "array", items: { type: "integer" }, description: "入力された配送先IDを効率的な訪問順に並べた配列" },
            routeAdvice: { type: "string", description: "ドライバー向けの具体的な配送順序と運行アドバイス" },
            warnings: { type: "array", items: { type: "string" }, description: "高さ制限、狭路、規制、住所確認などの注意点" },
          },
          required: ["orderedStopIds", "routeAdvice", "warnings"],
          additionalProperties: false,
        },
      },
    },
  });

  const raw = response.choices[0]?.message.content;
  const text = typeof raw === "string" ? raw : raw?.map(part => part.type === "text" ? part.text : "").join("") ?? "";
  try {
    const parsed = JSON.parse(text) as { orderedStopIds: number[]; routeAdvice: string; warnings: string[] };
    const validIds = new Set(input.destinations.map(destination => destination.id));
    const orderedStopIds = parsed.orderedStopIds.filter(id => validIds.has(id));
    for (const destination of input.destinations) {
      if (!orderedStopIds.includes(destination.id)) orderedStopIds.push(destination.id);
    }
    return {
      orderedStopIds,
      routeAdvice: parsed.routeAdvice || "入力された配送先を順番に確認してください。",
      warnings: parsed.warnings ?? [],
      vehicleProfile: VEHICLE_PROFILE,
      model: response.model,
    };
  } catch {
    throw new Error("Geminiから有効なルート計画を取得できませんでした。配送先を減らして再試行してください。");
  }
}
