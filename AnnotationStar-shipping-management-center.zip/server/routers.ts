import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createDeliveryTask, getDashboardSummary, listDeliveryTasks, listSchedules, removeDeliveryTask, setDeliveryTaskStatus, upsertSchedule } from "./db";
import { estimateDeliveryEtas, optimizeDeliveryRoute } from "./routePlanner";

const taskStatus = z.enum(["未完了", "対応中", "完了", "保留"]);
const shiftType = z.enum(["通常", "早番", "遅番", "休み", "有給"]);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    summary: protectedProcedure.input(z.object({ today: z.string() })).query(({ ctx, input }) => getDashboardSummary(ctx.user.id, input.today)),
  }),
  tasks: router({
    list: protectedProcedure.query(({ ctx }) => listDeliveryTasks(ctx.user.id)),
    create: protectedProcedure.input(z.object({ deliveryDate: z.string().min(10), destinationAddress: z.string().min(1).max(500), cargoInfo: z.string().min(1).max(500), status: taskStatus })).mutation(({ ctx, input }) => createDeliveryTask({ ...input, createdBy: ctx.user.id })),
    updateStatus: protectedProcedure.input(z.object({ id: z.number(), status: taskStatus })).mutation(({ ctx, input }) => setDeliveryTaskStatus({ ...input, userId: ctx.user.id })),
    remove: protectedProcedure.input(z.object({ id: z.number() })).mutation(({ ctx, input }) => removeDeliveryTask({ id: input.id, userId: ctx.user.id })),
  }),
  schedules: router({
    list: protectedProcedure.input(z.object({ yearMonth: z.string().regex(/^\d{4}-\d{2}$/).optional() })).query(({ ctx, input }) => listSchedules(ctx.user.id, input.yearMonth)),
    upsert: protectedProcedure.input(z.object({ yearMonth: z.string().regex(/^\d{4}-\d{2}$/), staffName: z.string().min(1).max(120), workDay: z.string().min(10), shiftType })).mutation(({ ctx, input }) => upsertSchedule({ ...input, createdBy: ctx.user.id })),
  }),
  routePlanner: router({
    optimize: protectedProcedure.input(z.object({
      currentLocation: z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) }).nullable(),
      destinations: z.array(z.object({ id: z.number().int().positive(), address: z.string().min(1).max(500), cargoInfo: z.string().max(500).optional() })).min(1).max(20),
    })).mutation(({ input }) => optimizeDeliveryRoute(input)),
    estimateEtas: protectedProcedure.input(z.object({
      currentLocation: z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) }),
      destinations: z.array(z.object({ id: z.number().int().positive(), address: z.string().min(1).max(500), cargoInfo: z.string().max(500).optional() })).max(20),
    })).mutation(({ input }) => estimateDeliveryEtas(input)),
  }),
});

export type AppRouter = typeof appRouter;
