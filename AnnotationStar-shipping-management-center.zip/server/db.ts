import { and, asc, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { dailySchedules, deliveryTasks, InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function requireDb() {
  if (!_db) throw new Error("Database is not configured");
  return _db;
}

export async function listDeliveryTasks(userId: number) {
  const db = requireDb();
  return db.select().from(deliveryTasks).where(eq(deliveryTasks.createdBy, userId)).orderBy(asc(deliveryTasks.deliveryDate), desc(deliveryTasks.id));
}

export async function createDeliveryTask(input: { deliveryDate: string; destinationAddress: string; cargoInfo: string; status: "未完了" | "対応中" | "完了" | "保留"; createdBy: number }) {
  const db = requireDb();
  await db.insert(deliveryTasks).values(input);
  return listDeliveryTasks(input.createdBy);
}

export async function setDeliveryTaskStatus(input: { id: number; status: "未完了" | "対応中" | "完了" | "保留"; userId: number }) {
  const db = requireDb();
  await db.update(deliveryTasks).set({ status: input.status }).where(and(eq(deliveryTasks.id, input.id), eq(deliveryTasks.createdBy, input.userId)));
  return listDeliveryTasks(input.userId);
}

export async function removeDeliveryTask(input: { id: number; userId: number }) {
  const db = requireDb();
  await db.delete(deliveryTasks).where(and(eq(deliveryTasks.id, input.id), eq(deliveryTasks.createdBy, input.userId)));
  return listDeliveryTasks(input.userId);
}

export async function listSchedules(userId: number, yearMonth?: string) {
  const db = requireDb();
  const condition = yearMonth ? and(eq(dailySchedules.createdBy, userId), eq(dailySchedules.yearMonth, yearMonth)) : eq(dailySchedules.createdBy, userId);
  return db.select().from(dailySchedules).where(condition).orderBy(desc(dailySchedules.workDay), asc(dailySchedules.staffName));
}

export async function upsertSchedule(input: { yearMonth: string; staffName: string; workDay: string; shiftType: "通常" | "早番" | "遅番" | "休み" | "有給"; createdBy: number }) {
  const db = requireDb();
  await db.insert(dailySchedules).values(input).onDuplicateKeyUpdate({ set: { shiftType: input.shiftType, updatedAt: new Date() } });
  return listSchedules(input.createdBy, input.yearMonth);
}

export async function getDashboardSummary(userId: number, today: string) {
  const db = requireDb();
  const [all, todayRows, completed, active, pending] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(deliveryTasks).where(eq(deliveryTasks.createdBy, userId)),
    db.select({ count: sql<number>`count(*)` }).from(deliveryTasks).where(and(eq(deliveryTasks.createdBy, userId), eq(deliveryTasks.deliveryDate, today))),
    db.select({ count: sql<number>`count(*)` }).from(deliveryTasks).where(and(eq(deliveryTasks.createdBy, userId), eq(deliveryTasks.deliveryDate, today), eq(deliveryTasks.status, "完了"))),
    db.select({ count: sql<number>`count(*)` }).from(deliveryTasks).where(and(eq(deliveryTasks.createdBy, userId), eq(deliveryTasks.deliveryDate, today), eq(deliveryTasks.status, "対応中"))),
    db.select({ count: sql<number>`count(*)` }).from(deliveryTasks).where(and(eq(deliveryTasks.createdBy, userId), eq(deliveryTasks.deliveryDate, today), eq(deliveryTasks.status, "未完了"))),
  ]);
  return { total: Number(all[0]?.count ?? 0), today: Number(todayRows[0]?.count ?? 0), completed: Number(completed[0]?.count ?? 0), active: Number(active[0]?.count ?? 0), pending: Number(pending[0]?.count ?? 0) };
}
