import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(user: TrpcContext["user"] = null): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("delivery management router", () => {
  it("requires authentication for dashboard queries", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.dashboard.summary({ today: "2026-09-11" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires authentication for task queries", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.tasks.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires authentication for route optimization", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.routePlanner.optimize({ currentLocation: null, destinations: [{ id: 1, address: "横浜市中区" }] })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires authentication for automatic ETA estimation", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.routePlanner.estimateEtas({ currentLocation: { lat: 35.44, lng: 139.63 }, destinations: [{ id: 1, address: "横浜市中区" }] })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("requires authentication for recording delivery completion", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.tasks.updateStatus({ id: 1, status: "完了" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("allows logout without an authenticated session", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.auth.logout()).resolves.toEqual({ success: true });
  });
});
