import { useEffect, useMemo, useRef, useState } from "react";
import { createWorker } from "tesseract.js";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { MapView } from "@/components/Map";
import { trpc } from "@/lib/trpc";
import { classifyCongestion, formatEta, type CongestionLevel } from "@/lib/routeEta";
import { findNextTaskId, shouldCompleteFromSwipe } from "@/lib/taskCompletion";
import { parseOcrDeliveryTasks, type ParsedOcrTask } from "@/lib/ocrTaskParser";
import { toast } from "sonner";
import {
  BarChart3,
  AlertCircle,
  CalendarDays,
  Check,
  ChevronRight,
  Clock3,
  ClipboardList,
  CloudUpload,
  FileDown,
  Gauge,
  Loader2,
  LogOut,
  Menu,
  LocateFixed,
  MapPin,
  Navigation,
  PackageCheck,
  Plus,
  ScanLine,
  Search,
  Route as RouteIcon,
  RefreshCw,
  Truck,
  UserRound,
  WandSparkles,
  X,
} from "lucide-react";

const taskStatuses = ["未完了", "対応中", "完了", "保留"] as const;
const shiftTypes = ["通常", "早番", "遅番", "休み", "有給"] as const;
type TaskStatus = (typeof taskStatuses)[number];
type ShiftType = (typeof shiftTypes)[number];
type Section = "dashboard" | "tasks" | "schedule" | "ocr" | "route";

const today = new Date().toISOString().slice(0, 10);
const thisMonth = today.slice(0, 7);

function csvDownload(filename: string, rows: Record<string, unknown>[]) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(","), ...rows.map(row => keys.map(key => `"${String(row[key] ?? "").replaceAll('"', '""')}"`).join(","))].join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function StatusPill({ status }: { status: string }) {
  return <span className={`status-pill status-${status === "完了" ? "done" : status === "対応中" ? "active" : status === "保留" ? "hold" : "pending"}`}>{status}</span>;
}

function EmptyState({ icon: Icon, title, body }: { icon: typeof ClipboardList; title: string; body: string }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={22} /></div><strong>{title}</strong><span>{body}</span></div>;
}

function LoginScreen({ error }: { error?: unknown }) {
  return <main className="login-shell"><div className="login-card"><div className="brand-mark large"><Truck size={28} /></div><p className="eyebrow">SHIPPING OPERATIONS</p><h1>配送業務センター</h1><p>配達タスク、日勤表、写真OCRをひとつの画面で管理できます。</p>{Boolean(error) && <div className="auth-alert" role="alert"><AlertCircle size={16} /><span>認証サービスに接続できませんでした。時間を置いて、もう一度お試しください。</span></div>}<button className="primary-button full" onClick={() => startLogin()}>Manusアカウントでログイン <ChevronRight size={17} /></button><small>安全なManus OAuth認証を利用します。ログイン後のみ業務データへアクセスできます。</small></div></main>;
}

function AppShell({ user, active, setActive, logout, children }: { user: { name?: string | null; email?: string | null }; active: Section; setActive: (section: Section) => void; logout: () => void; children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const items: { id: Section; label: string; icon: typeof BarChart3 }[] = [
    { id: "dashboard", label: "ダッシュボード", icon: BarChart3 },
    { id: "tasks", label: "配達タスク", icon: ClipboardList },
    { id: "route", label: "ルート最適化", icon: RouteIcon },
    { id: "schedule", label: "日勤表", icon: CalendarDays },
    { id: "ocr", label: "写真OCR", icon: ScanLine },
  ];
  return <div className="app-shell">
    {mobileOpen && <button className="scrim" onClick={() => setMobileOpen(false)} aria-label="メニューを閉じる" />}
    <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
      <div className="sidebar-brand"><div className="brand-mark"><Truck size={19} /></div><div><strong>配送業務センター</strong><span>OPERATIONS HUB</span></div><button className="icon-button mobile-close" onClick={() => setMobileOpen(false)}><X size={18} /></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{items.map(item => <button key={item.id} className={`nav-item ${active === item.id ? "active" : ""}`} onClick={() => { setActive(item.id); setMobileOpen(false); }}><item.icon size={18} /><span>{item.label}</span>{active === item.id && <ChevronRight className="nav-arrow" size={15} />}</button>)}</nav>
      <div className="sidebar-bottom"><div className="user-chip"><div className="avatar"><UserRound size={16} /></div><div className="user-meta"><strong>{user.name || "ユーザー"}</strong><span>{user.email || "ログイン中"}</span></div></div><button className="logout-button" onClick={() => logout()}><LogOut size={16} />ログアウト</button></div>
    </aside>
    <div className="main-shell"><header className="topbar"><button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20} /></button><div><span className="topbar-kicker">配送業務管理</span><span className="topbar-date">{new Intl.DateTimeFormat("ja-JP", { dateStyle: "full" }).format(new Date())}</span></div><div className="topbar-status"><span className="online-dot" />データ同期済み</div></header>{children}</div>
  </div>;
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="page-header"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}

function Dashboard({ setActive }: { setActive: (section: Section) => void }) {
  const summary = trpc.dashboard.summary.useQuery({ today });
  const tasks = trpc.tasks.list.useQuery();
  const rows = tasks.data ?? [];
  const todayRows = rows.filter(row => row.deliveryDate === today);
  const counts = useMemo(() => taskStatuses.map(status => ({ status, count: rows.filter(row => row.status === status).length })), [rows]);
  if (summary.isLoading || tasks.isLoading) return <Loading />;
  return <main className="content"><PageHeader eyebrow="OVERVIEW / TODAY" title="おはようございます" description="今日の配送状況と現場の進捗を確認しましょう。" action={<button className="primary-button" onClick={() => setActive("tasks")}><Plus size={17} />タスクを追加</button>} />
    <section className="metric-grid"><Metric label="本日の配達" value={summary.data?.today ?? 0} suffix="件" icon={PackageCheck} tone="orange" note="今日登録されている配達" /><Metric label="完了" value={summary.data?.completed ?? 0} suffix="件" icon={Check} tone="green" note="本日の完了タスク" /><Metric label="対応中" value={summary.data?.active ?? 0} suffix="件" icon={Truck} tone="blue" note="現場で対応中" /><Metric label="未完了" value={summary.data?.pending ?? 0} suffix="件" icon={ClipboardList} tone="purple" note="確認が必要なタスク" /></section>
    <section className="dashboard-grid"><div className="panel task-overview"><div className="panel-heading"><div><h2>本日の配達予定</h2><p>{today} のタスク一覧</p></div><button className="text-button" onClick={() => setActive("tasks")}>すべて見る <ChevronRight size={15} /></button></div>{todayRows.length ? <div className="task-list compact">{todayRows.slice(0, 5).map(task => <TaskRow key={task.id} task={task} />)}</div> : <EmptyState icon={PackageCheck} title="本日の配達予定はありません" body="配達タスクから予定を追加できます" />}</div><div className="panel distribution"><div className="panel-heading"><div><h2>全体ステータス</h2><p>登録済みタスクの内訳</p></div></div><div className="distribution-bars">{counts.map(item => <div className="distribution-row" key={item.status}><div><span>{item.status}</span><strong>{item.count}</strong></div><div className="bar-track"><span className={`bar-fill fill-${item.status === "完了" ? "green" : item.status === "対応中" ? "blue" : item.status === "保留" ? "orange" : "purple"}`} style={{ width: `${rows.length ? Math.max(item.count / rows.length * 100, item.count ? 8 : 0) : 0}%` }} /></div></div>)}</div></div></section>
    <section className="panel quick-panel"><div className="panel-heading"><div><h2>クイックアクセス</h2><p>日々の作業をすばやく開始</p></div></div><div className="quick-actions"><QuickAction icon={ClipboardList} title="配達を登録" body="新しい配送予定を作成" onClick={() => setActive("tasks")} /><QuickAction icon={RouteIcon} title="ルートを最適化" body="AIで配送順と注意点を確認" onClick={() => setActive("route")} /><QuickAction icon={CalendarDays} title="日勤表を確認" body="スタッフの勤務予定を管理" onClick={() => setActive("schedule")} /></div></section>
  </main>;
}

function Metric({ label, value, suffix, icon: Icon, tone, note }: { label: string; value: number; suffix: string; icon: typeof Truck; tone: string; note: string }) { return <div className="metric-card"><div className={`metric-icon ${tone}`}><Icon size={19} /></div><div className="metric-label">{label}</div><div className="metric-value">{value}<small>{suffix}</small></div><div className="metric-note">{note}</div></div>; }
function QuickAction({ icon: Icon, title, body, onClick }: { icon: typeof Truck; title: string; body: string; onClick: () => void }) { return <button className="quick-action" onClick={onClick}><span className="quick-icon"><Icon size={19} /></span><span><strong>{title}</strong><small>{body}</small></span><ChevronRight size={16} /></button>; }
function TaskRow({ task }: { task: { id: number; deliveryDate: string; destinationAddress: string; cargoInfo: string; status: string } }) { return <div className="task-row"><div className="task-id">#{String(task.id).padStart(3, "0")}</div><div className="task-main"><strong>{task.destinationAddress}</strong><span>{task.cargoInfo}</span></div><StatusPill status={task.status} /></div>; }
function Loading() { return <div className="loading"><Loader2 className="spin" size={23} /><span>データを読み込んでいます…</span></div>; }

type TaskEta = { taskId: number; eta: string; durationSeconds: number; delaySeconds: number; status: "on-time" | "late" | "unknown" };

function PaceBadge({ eta }: { eta?: TaskEta }) {
  if (!eta) return <span className="pace-badge pace-waiting"><Clock3 size={12} /> ETA待機中</span>;
  if (eta.status === "unknown") return <span className="pace-badge pace-unknown"><Clock3 size={12} /> 取得待ち</span>;
  const time = formatEta(new Date(eta.eta));
  return <span className={`pace-badge pace-${eta.status}`}><Clock3 size={12} /> {time}{eta.status === "late" && <small> +{Math.max(1, Math.round(eta.delaySeconds / 60))}分</small>}</span>;
}

function Tasks() {
  const [selectedDate, setSelectedDate] = useState(today);
  const [filter, setFilter] = useState<"すべて" | TaskStatus>("すべて");
  const [address, setAddress] = useState("");
  const [cargo, setCargo] = useState("");
  const [formDate, setFormDate] = useState(today);
  const [status, setStatus] = useState<TaskStatus>("未完了");
  const tasks = trpc.tasks.list.useQuery();
  const [driverLocation, setDriverLocation] = useState<DriverLocation | null>(null);
  const [etas, setEtas] = useState<TaskEta[]>([]);
  const [baselineEtas, setBaselineEtas] = useState<Record<number, number>>({});
  const [routeOrder, setRouteOrder] = useState<number[]>([]);
  const [nextTaskId, setNextTaskId] = useState<number | null>(null);
  const [swipeStart, setSwipeStart] = useState<{ id: number; x: number } | null>(null);
  const utils = trpc.useUtils();
  const estimateEtas = trpc.routePlanner.estimateEtas.useMutation();
  const reoptimize = trpc.routePlanner.optimize.useMutation();
  const create = trpc.tasks.create.useMutation({ onSuccess: () => { toast.success("配達タスクを追加しました"); setAddress(""); setCargo(""); utils.tasks.list.invalidate(); utils.dashboard.summary.invalidate(); }, onError: e => toast.error(e.message) });
  const update = trpc.tasks.updateStatus.useMutation({ onSuccess: () => { toast.success("ステータスを更新しました"); utils.tasks.list.invalidate(); utils.dashboard.summary.invalidate(); }, onError: e => toast.error(e.message) });
  const complete = trpc.tasks.updateStatus.useMutation({ onSuccess: (_data, variables) => { setEtas(current => current.filter(eta => eta.taskId !== variables.id)); setNextTaskId(findNextTaskId((tasks.data ?? []).map(task => task.id === variables.id ? { ...task, status: "完了" } : task), routeOrder)); utils.tasks.list.invalidate(); utils.dashboard.summary.invalidate(); toast.success("配送完了を記録しました。次のETAを更新しています"); }, onError: e => toast.error(e.message) });
  const remove = trpc.tasks.remove.useMutation({ onSuccess: () => { toast.success("タスクを削除しました"); utils.tasks.list.invalidate(); utils.dashboard.summary.invalidate(); }, onError: e => toast.error(e.message) });
  const visible = (tasks.data ?? []).filter(task => task.deliveryDate === selectedDate && (filter === "すべて" || task.status === filter));
  const visibleStatusKey = visible.map(task => `${task.id}:${task.status}`).join(",");
  useEffect(() => {
    if (!navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(position => setDriverLocation({ lat: position.coords.latitude, lng: position.coords.longitude, accuracy: position.coords.accuracy }), undefined, { enableHighAccuracy: true, maximumAge: 30000, timeout: 15000 });
    return () => navigator.geolocation.clearWatch(watchId);
  }, []);
  useEffect(() => {
    setEtas([]);
    setBaselineEtas({});
    setRouteOrder([]);
    setNextTaskId(null);
  }, [selectedDate, filter]);
  useEffect(() => {
    if (!driverLocation || !visible.length) return;
    let active = true;
    const refresh = async () => {
      try {
        const next = await estimateEtas.mutateAsync({ currentLocation: { lat: driverLocation.lat, lng: driverLocation.lng }, destinations: visible.filter(task => task.status !== "完了").slice(0, 20).map(task => ({ id: task.id, address: task.destinationAddress, cargoInfo: task.cargoInfo })) });
        if (!active) return;
        setEtas(next.map(item => ({ taskId: item.taskId, eta: item.eta, durationSeconds: item.durationSeconds, delaySeconds: item.delaySeconds, status: item.status })));
        setBaselineEtas(current => { if (Object.keys(current).length) return current; return Object.fromEntries(next.map(item => [item.taskId, new Date(item.eta).getTime()])); });
      } catch { /* keep the last automatic estimate visible during a transient maps failure */ }
    };
    refresh();
    const interval = window.setInterval(refresh, 60000);
    return () => { active = false; window.clearInterval(interval); };
  }, [driverLocation?.lat, driverLocation?.lng, selectedDate, filter, visibleStatusKey]);
  const paceEtas = etas.map(eta => { const baseline = baselineEtas[eta.taskId]; const scheduleDelay = baseline ? Math.max(0, new Date(eta.eta).getTime() - baseline) / 1000 : 0; return { ...eta, delaySeconds: Math.max(eta.delaySeconds, scheduleDelay), status: scheduleDelay >= 180 || eta.status === "late" ? "late" as const : eta.status }; });
  const orderedVisible = [...visible].sort((a, b) => { const ai = routeOrder.indexOf(a.id); const bi = routeOrder.indexOf(b.id); return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi); });
  useEffect(() => {
    setNextTaskId(findNextTaskId(orderedVisible, routeOrder));
  }, [routeOrder, visibleStatusKey]);
  function rerouteRemaining() {
    if (!driverLocation) return toast.error("現在地を取得中です。少し待ってから再試行してください");
    const remaining = orderedVisible.filter(task => task.status !== "完了");
    if (!remaining.length) return toast.success("残りの配送はありません");
    reoptimize.mutate({ currentLocation: { lat: driverLocation.lat, lng: driverLocation.lng }, destinations: remaining.map(task => ({ id: task.id, address: task.destinationAddress, cargoInfo: task.cargoInfo })) }, { onSuccess: result => { setRouteOrder(result.orderedStopIds); toast.success("残りの配送順を現在地から再計算しました"); }, onError: error => toast.error(error.message) });
  }
  function markComplete(taskId: number) {
    if (complete.isPending || (tasks.data ?? []).find(task => task.id === taskId)?.status === "完了") return;
    complete.mutate({ id: taskId, status: "完了" });
  }
  function handleSwipeEnd(taskId: number, endX: number) {
    if (!swipeStart || swipeStart.id !== taskId) return setSwipeStart(null);
    if (shouldCompleteFromSwipe(swipeStart.x, endX)) markComplete(taskId);
    setSwipeStart(null);
  }
  function submit(event: React.FormEvent) { event.preventDefault(); if (!address.trim() || !cargo.trim()) return toast.error("届け先住所と荷物情報を入力してください"); create.mutate({ deliveryDate: formDate, destinationAddress: address, cargoInfo: cargo, status }); }
  return <main className="content"><PageHeader eyebrow="OPERATIONS / TASKS" title="配達タスク" description="配送予定と自分のペースを確認します。ETAは現在地と交通状況から自動更新されます." action={<button className="secondary-button pace-reroute-button" onClick={rerouteRemaining} disabled={reoptimize.isPending}><RefreshCw size={15} className={reoptimize.isPending ? "spin" : ""} />{reoptimize.isPending ? "再計算中…" : "残りを再最適化"}</button>} /><section className="panel form-panel"><div className="panel-heading"><div><h2>新しい配達を登録</h2><p>届け先と荷物情報を入力してください</p></div><span className="required-note">* 必須項目</span></div><form className="form-grid" onSubmit={submit}><label>配達日<input type="date" value={formDate} onChange={e => setFormDate(e.target.value)} /></label><label className="wide">届け先住所<input value={address} onChange={e => setAddress(e.target.value)} placeholder="東京都〇〇区…" /></label><label>荷物情報<input value={cargo} onChange={e => setCargo(e.target.value)} placeholder="冷蔵 2箱 / 伝票No." /></label><label>初期ステータス<select value={status} onChange={e => setStatus(e.target.value as TaskStatus)}>{taskStatuses.map(value => <option key={value}>{value}</option>)}</select></label><div className="form-action"><button className="primary-button" disabled={create.isPending}>{create.isPending ? <Loader2 className="spin" size={16} /> : <Plus size={17} />}タスクを追加</button></div></form></section><section className="panel"><div className="panel-heading list-heading"><div><h2>配達予定一覧</h2><p>ETA自動更新：{driverLocation ? "現在地を取得済み" : "現在地を取得中"} / 更新間隔 約1分</p></div><button className="secondary-button" onClick={() => csvDownload("delivery_tasks.csv", visible.map(task => ({ ID: task.id, 配達日: task.deliveryDate, 届け先住所: task.destinationAddress, 荷物情報: task.cargoInfo, ステータス: task.status })))}><FileDown size={16} />CSV出力</button></div><div className="filters"><label><CalendarDays size={16} />表示日<input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} /></label><label><Search size={16} />ステータス<select value={filter} onChange={e => setFilter(e.target.value as "すべて" | TaskStatus)}><option>すべて</option>{taskStatuses.map(value => <option key={value}>{value}</option>)}</select></label><span className="result-count">{visible.length}件</span></div>{tasks.isLoading ? <Loading /> : visible.length ? <div className="task-list">{orderedVisible.map(task => <div className={`task-row full pace-task-row ${nextTaskId === task.id ? "next-task" : ""} ${task.status === "完了" ? "task-completed" : ""}`} key={task.id} onTouchStart={event => setSwipeStart({ id: task.id, x: event.touches[0]?.clientX ?? 0 })} onTouchEnd={event => handleSwipeEnd(task.id, event.changedTouches[0]?.clientX ?? 0)}><div className="task-id">#{String(task.id).padStart(3, "0")}</div><div className="task-main"><strong>{task.destinationAddress}</strong><span>{task.cargoInfo} · {task.deliveryDate}</span>{nextTaskId === task.id && task.status !== "完了" && <small className="next-stop-label">次の目的地</small>}</div><PaceBadge eta={paceEtas.find(eta => eta.taskId === task.id)} />{task.status === "完了" ? <span className="completion-mark"><Check size={14} />完了</span> : <button className="complete-button" onClick={() => markComplete(task.id)} disabled={complete.isPending}><Check size={14} />完了</button>}<select className="inline-status" value={task.status} onChange={e => update.mutate({ id: task.id, status: e.target.value as TaskStatus })}>{taskStatuses.map(value => <option key={value}>{value}</option>)}</select><button className="icon-button danger" aria-label="削除" onClick={() => { if (confirm("このタスクを削除しますか？")) remove.mutate({ id: task.id }); }}><X size={17} /></button></div>)}</div> : <EmptyState icon={ClipboardList} title="条件に一致するタスクはありません" body="別の日付を選択するか、新しいタスクを登録してください" />}</section></main>;
}

function Schedule() {
  const [month, setMonth] = useState(thisMonth);
  const [staff, setStaff] = useState("");
  const [workDay, setWorkDay] = useState(today);
  const [shift, setShift] = useState<ShiftType>("通常");
  const schedules = trpc.schedules.list.useQuery({ yearMonth: month });
  const utils = trpc.useUtils();
  const save = trpc.schedules.upsert.useMutation({ onSuccess: () => { toast.success("勤務予定を保存しました"); setStaff(""); utils.schedules.list.invalidate(); }, onError: e => toast.error(e.message) });
  function submit(event: React.FormEvent) { event.preventDefault(); if (!staff.trim() || workDay.slice(0, 7) !== month) return toast.error("スタッフ名と対象年月を確認してください"); save.mutate({ yearMonth: month, staffName: staff, workDay, shiftType: shift }); }
  const rows = schedules.data ?? [];
  return <main className="content"><PageHeader eyebrow="PEOPLE / SCHEDULE" title="日勤表" description="スタッフごとの勤務日とシフトを月単位で管理します。" /><section className="panel form-panel"><div className="panel-heading"><div><h2>勤務予定を登録</h2><p>同じスタッフ・日付を登録するとシフトが更新されます</p></div></div><form className="form-grid" onSubmit={submit}><label>対象年月<input type="month" value={month} onChange={e => { setMonth(e.target.value); setWorkDay(`${e.target.value}-01`); }} /></label><label>スタッフ名<input value={staff} onChange={e => setStaff(e.target.value)} placeholder="山田 太郎" /></label><label>勤務日<input type="date" value={workDay} onChange={e => setWorkDay(e.target.value)} /></label><label>シフト<select value={shift} onChange={e => setShift(e.target.value as ShiftType)}>{shiftTypes.map(value => <option key={value}>{value}</option>)}</select></label><div className="form-action"><button className="primary-button" disabled={save.isPending}>{save.isPending ? <Loader2 className="spin" size={16} /> : <Plus size={17} />}勤務予定を保存</button></div></form></section><section className="panel"><div className="panel-heading list-heading"><div><h2>{month} の日勤表</h2><p>{rows.length}件の勤務予定</p></div><button className="secondary-button" onClick={() => csvDownload("daily_schedule.csv", rows.map(row => ({ ID: row.id, 対象年月: row.yearMonth, スタッフ名: row.staffName, 勤務日: row.workDay, シフト: row.shiftType })))}><FileDown size={16} />CSV出力</button></div>{schedules.isLoading ? <Loading /> : rows.length ? <div className="schedule-table"><div className="schedule-head"><span>勤務日</span><span>スタッフ名</span><span>シフト</span></div>{rows.map(row => <div className="schedule-row" key={row.id}><span>{row.workDay}</span><strong>{row.staffName}</strong><StatusPill status={row.shiftType} /></div>)}</div> : <EmptyState icon={CalendarDays} title="勤務予定がありません" body="上のフォームから最初の予定を登録してください" />}</section></main>;
}

type RoutePlan = { orderedStopIds: number[]; routeAdvice: string; warnings: string[]; vehicleProfile: string; model: string };
type DriverLocation = { lat: number; lng: number; accuracy?: number };
type StopEta = { taskId: number; durationSeconds: number; trafficDelaySeconds: number; distanceMeters: number; etaLabel: string; congestion: CongestionLevel };

function RoutePlanner() {
  const tasks = trpc.tasks.list.useQuery();
  const optimize = trpc.routePlanner.optimize.useMutation();
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [driverLocation, setDriverLocation] = useState<DriverLocation | null>(null);
  const [locationStatus, setLocationStatus] = useState("現在地は未取得です");
  const [plan, setPlan] = useState<RoutePlan | null>(null);
  const [routeEstimate, setRouteEstimate] = useState<{ distance: string; duration: string } | null>(null);
  const [stopEtas, setStopEtas] = useState<StopEta[]>([]);
  const [trafficUpdatedAt, setTrafficUpdatedAt] = useState<Date | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const rendererRef = useRef<google.maps.DirectionsRenderer | null>(null);
  const driverMarkerRef = useRef<google.maps.marker.AdvancedMarkerElement | null>(null);
  const stopMarkersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const selectedTasks = (tasks.data ?? []).filter(task => selectedIds.includes(task.id));

  useEffect(() => {
    if (!selectedIds.length && tasks.data?.length) {
      setSelectedIds(tasks.data.filter(task => task.status !== "完了").slice(0, 20).map(task => task.id));
    }
  }, [selectedIds.length, tasks.data]);

  function showDriverLocation(location: DriverLocation) {
    if (!mapRef.current || !window.google?.maps?.marker) return;
    mapRef.current.setCenter({ lat: location.lat, lng: location.lng });
    if (!driverMarkerRef.current) {
      driverMarkerRef.current = new google.maps.marker.AdvancedMarkerElement({ map: mapRef.current, position: { lat: location.lat, lng: location.lng }, title: "ドライバー現在地" });
    } else {
      driverMarkerRef.current.position = { lat: location.lat, lng: location.lng };
    }
  }

  function getLocation() {
    if (!navigator.geolocation) return setLocationStatus("このブラウザでは現在地を取得できません");
    setLocationStatus("現在地を取得しています…");
    navigator.geolocation.getCurrentPosition(
      position => { const nextLocation = { lat: position.coords.latitude, lng: position.coords.longitude, accuracy: position.coords.accuracy }; setDriverLocation(nextLocation); showDriverLocation(nextLocation); setLocationStatus(`現在地を取得済み（誤差 約${Math.round(position.coords.accuracy)}m）`); },
      error => setLocationStatus(error.code === error.PERMISSION_DENIED ? "位置情報の利用が許可されていません" : "現在地を取得できませんでした"),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    );
  }

  function clearStopMarkers() {
    stopMarkersRef.current.forEach(marker => { marker.map = null; });
    stopMarkersRef.current = [];
  }

  function renderStopEtaMarkers(orderedTasks: NonNullable<typeof tasks.data>[number][], etas: StopEta[]) {
    if (!mapRef.current || !window.google?.maps?.marker) return;
    clearStopMarkers();
    const geocoder = new google.maps.Geocoder();
    orderedTasks.forEach((task, index) => {
      const eta = etas.find(item => item.taskId === task.id);
      if (!eta) return;
      geocoder.geocode({ address: task.destinationAddress }, (results, status) => {
        if (status !== "OK" || !results?.[0]) return;
        const badge = document.createElement("div");
        badge.className = `eta-map-badge eta-${eta.congestion}`;
        badge.innerHTML = `<span class="eta-map-number">${index + 1}</span><span><b>${eta.etaLabel}</b><small>${eta.congestion === "heavy" ? "渋滞" : eta.congestion === "moderate" ? "混雑" : eta.congestion === "smooth" ? "順調" : "交通状況"}</small></span>`;
        const marker = new google.maps.marker.AdvancedMarkerElement({ map: mapRef.current, position: results[0].geometry.location, content: badge, title: `${index + 1}番目 ${task.destinationAddress} / ETA ${eta.etaLabel}` });
        stopMarkersRef.current.push(marker);
      });
    });
  }

  function drawDirections(orderedIds: number[]) {
    if (!mapRef.current) return;
    const orderedTasks = orderedIds.map(id => (tasks.data ?? []).find(task => task.id === id)).filter(Boolean) as NonNullable<typeof tasks.data>[number][];
    if (orderedTasks.length < 1) return;
    const directionsService = new google.maps.DirectionsService();
    const renderer = rendererRef.current ?? new google.maps.DirectionsRenderer({ map: mapRef.current, suppressMarkers: false, polylineOptions: { strokeColor: "#e68c4a", strokeWeight: 5 } });
    rendererRef.current = renderer;
    const origin = driverLocation ? { lat: driverLocation.lat, lng: driverLocation.lng } : orderedTasks[0].destinationAddress;
    const destination = orderedTasks[orderedTasks.length - 1].destinationAddress;
    const waypoints = orderedTasks.slice(driverLocation ? 0 : 1, -1).map(task => ({ location: task.destinationAddress, stopover: true }));
    directionsService.route({ origin, destination, waypoints, travelMode: google.maps.TravelMode.DRIVING, drivingOptions: { departureTime: new Date(), trafficModel: google.maps.TrafficModel.BEST_GUESS } }, (result, status) => {
      if (status !== "OK" || !result) return toast.error(`Google Mapsのルート取得に失敗しました（${status}）`);
      renderer.setDirections(result);
      const legs = result.routes[0]?.legs ?? [];
      let cumulativeSeconds = driverLocation ? 0 : 0;
      const etas: StopEta[] = orderedTasks.map((task, index) => {
        const leg = legs[driverLocation ? index : index - 1];
        if (!driverLocation && index === 0) return { taskId: task.id, durationSeconds: 0, trafficDelaySeconds: 0, distanceMeters: 0, etaLabel: "出発地点", congestion: "unknown" };
        const durationSeconds = leg?.duration_in_traffic?.value ?? leg?.duration?.value ?? 0;
        const baseDurationSeconds = leg?.duration?.value ?? durationSeconds;
        cumulativeSeconds += durationSeconds;
        const trafficDelaySeconds = Math.max(0, durationSeconds - baseDurationSeconds);
        const congestion = classifyCongestion(trafficDelaySeconds, Boolean(leg));
        const eta = new Date(Date.now() + cumulativeSeconds * 1000);
        return { taskId: task.id, durationSeconds, trafficDelaySeconds, distanceMeters: leg?.distance?.value ?? 0, etaLabel: formatEta(eta), congestion };
      });
      setStopEtas(etas);
      setTrafficUpdatedAt(new Date());
      const totalDistance = legs.reduce((total, leg) => total + (leg.distance?.value ?? 0), 0);
      const totalDuration = legs.reduce((total, leg) => total + (leg.duration_in_traffic?.value ?? leg.duration?.value ?? 0), 0);
      setRouteEstimate({ distance: `${(totalDistance / 1000).toFixed(1)} km`, duration: `${Math.round(totalDuration / 60)} 分（渋滞予測）` });
      renderStopEtaMarkers(orderedTasks, etas);
      toast.success("渋滞を考慮したルートと各停車地のETAを更新しました");
    });
  }

  function optimizeRoute() {
    if (!selectedTasks.length) return toast.error("配送先を1件以上選択してください");
    optimize.mutate({ currentLocation: driverLocation ? { lat: driverLocation.lat, lng: driverLocation.lng } : null, destinations: selectedTasks.map(task => ({ id: task.id, address: task.destinationAddress, cargoInfo: task.cargoInfo })) }, { onSuccess: nextPlan => { setPlan(nextPlan); drawDirections(nextPlan.orderedStopIds); toast.success("Geminiが配送順を最適化しました"); }, onError: error => toast.error(error.message) });
  }

  function openGoogleNavigation() {
    const orderedTasks = (plan?.orderedStopIds ?? selectedIds).map(id => (tasks.data ?? []).find(task => task.id === id)).filter(Boolean) as NonNullable<typeof tasks.data>[number][];
    if (!orderedTasks.length) return toast.error("先に配送先を選択してください");
    const params = new URLSearchParams({ api: "1", destination: orderedTasks[orderedTasks.length - 1].destinationAddress, travelmode: "driving" });
    if (driverLocation) params.set("origin", `${driverLocation.lat},${driverLocation.lng}`);
    if (orderedTasks.length > 1) params.set("waypoints", orderedTasks.slice(0, -1).map(task => task.destinationAddress).join("|"));
    window.open(`https://www.google.com/maps/dir/?${params.toString()}`, "_blank", "noopener,noreferrer");
  }

  return <main className="content"><PageHeader eyebrow="DRIVER TOOLS / ROUTE" title="配送ルート最適化" description="現在地・車両条件・配送先をもとにAIが順番を提案し、交通状況を考慮した実走ルートを表示します。" action={<button className="primary-button" onClick={getLocation}><LocateFixed size={17} />現在地を取得</button>} /><div className="vehicle-banner"><div className="vehicle-icon"><Truck size={20} /></div><div><strong>青ナンバー軽トラック</strong><span>ハイルーフ仕様・全高約2.0m前後 / 高架下・高さ制限に注意</span></div><span className="vehicle-fixed">固定車両条件</span></div><section className="route-layout"><div className="panel route-controls"><div className="panel-heading"><div><h2>配送先を選択</h2><p>最大20件まで。完了済みは初期選択から除外</p></div><span className="route-count">{selectedIds.length}件選択</span></div><div className="location-status"><MapPin size={16} /><span>{locationStatus}</span>{driverLocation && <span className="location-coord">{driverLocation.lat.toFixed(5)}, {driverLocation.lng.toFixed(5)}</span>}</div><div className="route-task-picker">{tasks.isLoading ? <Loading /> : (tasks.data ?? []).length ? (tasks.data ?? []).map(task => <label className={`route-task-option ${selectedIds.includes(task.id) ? "selected" : ""}`} key={task.id}><input type="checkbox" checked={selectedIds.includes(task.id)} onChange={() => setSelectedIds(current => current.includes(task.id) ? current.filter(id => id !== task.id) : current.length >= 20 ? current : [...current, task.id])} /><span className="route-checkbox" /><span className="route-task-copy"><strong>#{String(task.id).padStart(3, "0")} {task.destinationAddress}</strong><small>{task.cargoInfo}</small></span><StatusPill status={task.status} /></label>) : <EmptyState icon={RouteIcon} title="配送先がありません" body="配達タスクを登録してからルートを作成してください" />}</div><button className="primary-button full route-optimize-button" disabled={optimize.isPending || !selectedIds.length} onClick={optimizeRoute}>{optimize.isPending ? <><Loader2 className="spin" size={17} />Geminiが最適化中…</> : <><WandSparkles size={17} />Geminiで配送順を最適化</>}</button></div><div className="panel map-panel"><div className="panel-heading"><div><h2>リアルタイムルート</h2><p>Google Maps / Directions + Distance Matrix / best_guess</p></div><button className="secondary-button" onClick={openGoogleNavigation}><Navigation size={16} />カーナビで開く</button></div><div className="traffic-toolbar"><div className="traffic-live"><span className="traffic-live-dot" /> <strong>現在の交通状況</strong><span>{trafficUpdatedAt ? `${formatEta(trafficUpdatedAt)} 更新` : "ルート作成後に表示"}</span></div><button className="icon-button traffic-refresh" onClick={() => plan && drawDirections(plan.orderedStopIds)} disabled={!plan} aria-label="交通状況を更新"><RefreshCw size={15} /></button></div><div className="traffic-legend"><span><i className="legend-line smooth" />順調</span><span><i className="legend-line moderate" />混雑</span><span><i className="legend-line heavy" />渋滞</span><span className="traffic-legend-note"><Gauge size={13} /> best_guess</span></div><MapView className="route-map" initialCenter={driverLocation ? { lat: driverLocation.lat, lng: driverLocation.lng } : { lat: 35.4437, lng: 139.638 }} initialZoom={12} onMapReady={map => { mapRef.current = map; new google.maps.TrafficLayer().setMap(map); if (driverLocation) showDriverLocation(driverLocation); if (plan) drawDirections(plan.orderedStopIds); }} />{routeEstimate && <div className="route-estimate"><div><span>推定距離</span><strong>{routeEstimate.distance}</strong></div><div><span>推定所要時間</span><strong>{routeEstimate.duration}</strong></div></div>}{stopEtas.length > 0 && <div className="eta-panel"><div className="eta-panel-heading"><div><span className="result-label">LIVE ETA</span><h3>停車地ごとの到着予想</h3></div><span className="eta-panel-note"><Clock3 size={13} />到着時刻は交通状況で変動</span></div><div className="eta-stop-list">{(plan?.orderedStopIds ?? selectedIds).map((id, index) => { const task = (tasks.data ?? []).find(row => row.id === id); const eta = stopEtas.find(item => item.taskId === id); if (!task || !eta) return null; return <div className="eta-stop-row" key={id}><span className="stop-number">{index + 1}</span><div className="eta-stop-address"><strong>{task.destinationAddress}</strong><small>{task.cargoInfo}</small></div><div className={`congestion-chip congestion-${eta.congestion}`}><span className="congestion-dot" />{eta.congestion === "heavy" ? "渋滞" : eta.congestion === "moderate" ? "混雑" : eta.congestion === "smooth" ? "順調" : "未取得"}</div><div className="eta-stop-time"><strong>{eta.etaLabel}</strong><small>{eta.etaLabel === "出発地点" ? "開始地点" : `所要 ${Math.max(1, Math.round(eta.durationSeconds / 60))}分`}</small></div></div>; })}</div></div>}{plan && <div className="route-result"><div className="route-result-heading"><div><span className="result-label">AI ROUTE PLAN</span><h3>推奨配送順</h3></div><span className="model-tag">{plan.model}</span></div><div className="ordered-stops">{plan.orderedStopIds.map((id, index) => { const task = (tasks.data ?? []).find(row => row.id === id); return task ? <div className="ordered-stop" key={id}><span className="stop-number">{index + 1}</span><div><strong>{task.destinationAddress}</strong><small>{task.cargoInfo}</small></div></div> : null; })}</div><div className="advice-box"><strong>配送アドバイス</strong><p>{plan.routeAdvice}</p></div>{plan.warnings.length > 0 && <div className="warning-box"><strong>注意事項</strong><ul>{plan.warnings.map((warning, index) => <li key={`${warning}-${index}`}>{warning}</li>)}</ul></div>}</div>}</div></section><div className="route-note"><RouteIcon size={17} /><span><strong>最終確認：</strong>AIの提案は補助情報です。Google Mapsの実走ルート、現地標識、時間帯規制、高さ制限を出発前と各停車地点で必ず確認してください。</span></div></main>;
}

function OCR() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [text, setText] = useState("");
  const [running, setRunning] = useState(false);
  const [deliveryDate, setDeliveryDate] = useState(today);
  const [parsedTasks, setParsedTasks] = useState<ParsedOcrTask[]>([]);
  const utils = trpc.useUtils();
  const createTask = trpc.tasks.create.useMutation();
  function choose(event: React.ChangeEvent<HTMLInputElement>) { const next = event.target.files?.[0]; if (!next) return; setFile(next); setPreview(URL.createObjectURL(next)); setText(""); }
  async function registerParsedTasks(tasksToRegister: ParsedOcrTask[]) { if (!tasksToRegister.length) return; try { await Promise.all(tasksToRegister.map(task => createTask.mutateAsync(task))); utils.tasks.list.invalidate(); utils.dashboard.summary.invalidate(); toast.success(`${tasksToRegister.length}件の配達タスクを自動登録しました`); } catch (error) { toast.error(`タスク登録に失敗しました: ${String(error)}`); } }
  async function runOCR() { if (!file || !preview) return; setRunning(true); setText(""); setParsedTasks([]); try { const worker = await createWorker("jpn+eng"); const result = await worker.recognize(preview); const recognized = result.data.text; setText(recognized); const extracted = parseOcrDeliveryTasks(recognized, deliveryDate); setParsedTasks(extracted); await worker.terminate(); if (extracted.length) await registerParsedTasks(extracted); else toast.warning("住所候補を見つけられませんでした。認識結果を確認してください"); if (extracted.length) toast.success("OCRと配達タスク登録が完了しました"); } catch (error) { toast.error(`OCRに失敗しました: ${String(error)}`); } finally { setRunning(false); } }
  return <main className="content"><PageHeader eyebrow="INTAKE / OCR" title="写真OCR" description="写真から住所を読み取り、配達タスクへ自動登録します。" /><section className="ocr-layout"><div className="panel upload-panel"><div className="panel-heading"><div><h2>画像をアップロード</h2><p>PNG・JPG・WEBPに対応</p></div></div><label className="upload-drop"><input type="file" accept="image/png,image/jpeg,image/webp" onChange={choose} /><CloudUpload size={28} /><strong>画像を選択</strong><span>クリックまたはファイルをドロップ</span></label>{preview && <img className="ocr-preview" src={preview} alt="アップロードした画像" />}<label className="ocr-date">配達日<input type="date" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} /></label><button className="primary-button full" disabled={!file || running || createTask.isPending} onClick={runOCR}>{running ? <><Loader2 className="spin" size={17} />解析・自動登録中…</> : <><ScanLine size={17} />OCRして配達タスクへ自動登録</>}</button></div><div className="panel result-panel"><div className="panel-heading"><div><h2>認識結果</h2><p>抽出した住所候補を自動でタスク化します</p></div>{text && <button className="secondary-button" onClick={() => { navigator.clipboard.writeText(text); toast.success("クリップボードにコピーしました"); }}>コピー</button>}</div><textarea className="ocr-result" value={text} onChange={e => { setText(e.target.value); setParsedTasks(parseOcrDeliveryTasks(e.target.value, deliveryDate)); }} placeholder="OCRを実行すると、ここに認識結果が表示されます。\n\n※画像の品質や文字の種類によっては誤認識が発生する場合があります。" />{parsedTasks.length > 0 && <div className="ocr-task-summary"><strong>{parsedTasks.length}件の住所候補を検出</strong><span>{parsedTasks.slice(0, 3).map(task => task.destinationAddress).join(" / ")}{parsedTasks.length > 3 ? " …" : ""}</span></div>}{text && <button className="secondary-button" onClick={() => { const blob = new Blob([text], { type: "text/plain;charset=utf-8" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = "ocr_result.txt"; link.click(); URL.revokeObjectURL(url); }}><FileDown size={16} />テキスト保存</button>}</div></section><div className="notice"><ScanLine size={18} /><span><strong>自動登録：</strong>OCRで住所らしい行を抽出し、選択した配達日に「未完了」タスクとして登録します。誤認識がある場合はタスク一覧で修正してください。</span></div></main>;
}

export default function Home() {
  const { user, loading, error, isAuthenticated, logout } = useAuth();
  const [active, setActive] = useState<Section>("dashboard");
  if (loading) return <Loading />;
  if (!isAuthenticated || !user) return <LoginScreen error={error} />;
  return <AppShell user={user} active={active} setActive={setActive} logout={logout}>{active === "dashboard" && <Dashboard setActive={setActive} />}{active === "tasks" && <Tasks />}{active === "route" && <RoutePlanner />}{active === "schedule" && <Schedule />}{active === "ocr" && <OCR />}</AppShell>;
}
