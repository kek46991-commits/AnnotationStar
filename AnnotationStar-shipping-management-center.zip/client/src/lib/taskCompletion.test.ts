import { describe, expect, it } from "vitest";
import { findNextTaskId, shouldCompleteFromSwipe, SWIPE_COMPLETE_THRESHOLD } from "./taskCompletion";

describe("task completion helpers", () => {
  it("requires a deliberate left swipe", () => {
    expect(shouldCompleteFromSwipe(300, 300 - SWIPE_COMPLETE_THRESHOLD)).toBe(true);
    expect(shouldCompleteFromSwipe(300, 300 - SWIPE_COMPLETE_THRESHOLD + 1)).toBe(false);
    expect(shouldCompleteFromSwipe(300, 360)).toBe(false);
  });

  it("selects the next unfinished task in the current route order", () => {
    const tasks = [{ id: 1, status: "完了" }, { id: 2, status: "未完了" }, { id: 3, status: "対応中" }];
    expect(findNextTaskId(tasks, [3, 2, 1])).toBe(3);
    expect(findNextTaskId(tasks, [1, 2, 3])).toBe(2);
  });

  it("returns null when all tasks are complete", () => {
    expect(findNextTaskId([{ id: 1, status: "完了" }])).toBeNull();
  });
});
