import { describe, expect, it } from "vitest";
import { parseOcrDeliveryTasks } from "./ocrTaskParser";

describe("OCR delivery task parser", () => {
  it("extracts unique address-like lines as incomplete delivery tasks", () => {
    const tasks = parseOcrDeliveryTasks("配送スケジュール一覧\n大阪府大阪市北区梅田1丁目1番地\n大阪府大阪市北区梅田1丁目1番地\n担当 山田", "2026-09-12");
    expect(tasks).toHaveLength(1);
    expect(tasks[0]).toMatchObject({ deliveryDate: "2026-09-12", destinationAddress: "大阪府大阪市北区梅田1丁目1番地", cargoInfo: "写真OCRから自動登録", status: "未完了" });
  });

  it("ignores headers and short non-address text", () => {
    expect(parseOcrDeliveryTasks("日勤表\n担当\n合計 3件\n12345", "2026-09-12")).toEqual([]);
  });
});
