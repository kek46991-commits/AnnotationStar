export const SWIPE_COMPLETE_THRESHOLD = 84;

export function shouldCompleteFromSwipe(startX: number, endX: number, threshold = SWIPE_COMPLETE_THRESHOLD): boolean {
  return startX - endX >= threshold;
}

export function findNextTaskId<T extends { id: number; status: string }>(tasks: T[], orderedIds: number[] = []): number | null {
  const ordered = orderedIds.length
    ? [...tasks].sort((a, b) => {
        const ai = orderedIds.indexOf(a.id);
        const bi = orderedIds.indexOf(b.id);
        return (ai < 0 ? Number.MAX_SAFE_INTEGER : ai) - (bi < 0 ? Number.MAX_SAFE_INTEGER : bi);
      })
    : tasks;
  return ordered.find(task => task.status !== "完了")?.id ?? null;
}
