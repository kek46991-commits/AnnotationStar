export type CongestionLevel = "smooth" | "moderate" | "heavy" | "unknown";

export function classifyCongestion(trafficDelaySeconds: number, hasRoute: boolean): CongestionLevel {
  if (!hasRoute) return "unknown";
  if (trafficDelaySeconds >= 600) return "heavy";
  if (trafficDelaySeconds >= 180) return "moderate";
  return "smooth";
}

export function formatEta(timestamp: Date): string {
  return timestamp.toLocaleTimeString("ja-JP", { timeZone: "Asia/Tokyo", hour: "2-digit", minute: "2-digit" });
}
