export type ParsedOcrTask = {
  deliveryDate: string;
  destinationAddress: string;
  cargoInfo: string;
  status: "未完了";
};

const ADDRESS_SIGNAL = /(都|道|府|県|市|区|町|村|丁目|番地|号)/;
const STRONG_ADDRESS_SIGNAL = /(〒\s*\d{3}[-ー]?\d{4}|(?:都|道|府|県).{1,18}(?:市|区|町|村)|(?:市|区).{1,18}(?:町|丁目|番地|号))/;
const HEADER_WORDS = /(スケジュール|一覧表|日勤表|配送|担当|合計|合格|備考|名前|電話|伝票|曜日)/;

function normalizeLine(line: string): string {
  return line.replace(/[|｜]/g, " ").replace(/[　\t]+/g, " ").replace(/^[-_=・:：\s]+|[-_=・:：\s]+$/g, "").trim();
}

export function parseOcrDeliveryTasks(text: string, deliveryDate: string): ParsedOcrTask[] {
  const lines = text.split(/\r?\n/).map(normalizeLine).filter(Boolean);
  const candidates = lines.filter(line => {
    if (line.length < 5 || line.length > 120 || HEADER_WORDS.test(line)) return false;
    const signals = (line.match(/[都道府県市区町村丁目番地号]/g) ?? []).length;
    return STRONG_ADDRESS_SIGNAL.test(line) || (ADDRESS_SIGNAL.test(line) && signals >= 2);
  });
  const unique = Array.from(new Set(candidates));
  return unique.slice(0, 20).map(destinationAddress => ({
    deliveryDate,
    destinationAddress,
    cargoInfo: "写真OCRから自動登録",
    status: "未完了" as const,
  }));
}
