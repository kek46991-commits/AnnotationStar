import { describe, expect, it } from "vitest";
import { classifyCongestion, formatEta } from "./routeEta";

describe("route ETA utilities", () => {
  it("classifies traffic delay into the driver-facing levels", () => {
    expect(classifyCongestion(0, true)).toBe("smooth");
    expect(classifyCongestion(179, true)).toBe("smooth");
    expect(classifyCongestion(180, true)).toBe("moderate");
    expect(classifyCongestion(599, true)).toBe("moderate");
    expect(classifyCongestion(600, true)).toBe("heavy");
  });

  it("returns unknown when no route leg is available", () => {
    expect(classifyCongestion(999, false)).toBe("unknown");
  });

  it("formats the ETA as a concise Japanese time label", () => {
    expect(formatEta(new Date("2026-09-11T08:05:00+09:00"))).toMatch(/^08:05$/);
  });
});
