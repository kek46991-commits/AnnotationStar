import { int, mysqlEnum, mysqlTable, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const dailySchedules = mysqlTable(
  "daily_schedules",
  {
    id: int("id").autoincrement().primaryKey(),
    yearMonth: varchar("yearMonth", { length: 7 }).notNull(),
    staffName: varchar("staffName", { length: 120 }).notNull(),
    workDay: varchar("workDay", { length: 10 }).notNull(),
    shiftType: mysqlEnum("shiftType", ["通常", "早番", "遅番", "休み", "有給"]).default("通常").notNull(),
    createdBy: int("createdBy").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    scheduleOwnerDateUnique: uniqueIndex("schedule_owner_date_unique").on(table.createdBy, table.yearMonth, table.staffName, table.workDay),
  }),
);

export const deliveryTasks = mysqlTable(
  "delivery_tasks",
  {
    id: int("id").autoincrement().primaryKey(),
    deliveryDate: varchar("deliveryDate", { length: 10 }).notNull(),
    destinationAddress: varchar("destinationAddress", { length: 500 }).notNull(),
    cargoInfo: varchar("cargoInfo", { length: 500 }).notNull(),
    status: mysqlEnum("status", ["未完了", "対応中", "完了", "保留"]).default("未完了").notNull(),
    createdBy: int("createdBy").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type DailySchedule = typeof dailySchedules.$inferSelect;
export type DeliveryTask = typeof deliveryTasks.$inferSelect;
