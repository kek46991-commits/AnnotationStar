CREATE TABLE `daily_schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`yearMonth` varchar(7) NOT NULL,
	`staffName` varchar(120) NOT NULL,
	`workDay` varchar(10) NOT NULL,
	`shiftType` enum('通常','早番','遅番','休み','有給') NOT NULL DEFAULT '通常',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_schedules_id` PRIMARY KEY(`id`),
	CONSTRAINT `schedule_owner_date_unique` UNIQUE(`createdBy`,`yearMonth`,`staffName`,`workDay`)
);
--> statement-breakpoint
CREATE TABLE `delivery_tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`deliveryDate` varchar(10) NOT NULL,
	`destinationAddress` varchar(500) NOT NULL,
	`cargoInfo` varchar(500) NOT NULL,
	`status` enum('未完了','対応中','完了','保留') NOT NULL DEFAULT '未完了',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `delivery_tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `name` varchar(255);